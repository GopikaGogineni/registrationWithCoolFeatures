var strength="";
var jsonObj,registerUser,readStore;

//Create a Javascript object
function createObject(){

  firstname = document.getElementById("fname").value;
  lastname = document.getElementById("lname").value;
  email = document.getElementById("emailId").value;
  password = document.getElementById("pwd").value;
  passwordStrength = strength;
  dob = document.getElementById("dob").value;
  dobLocal = document.getElementById("dobLocal").value;
  ssn = document.getElementById("ssn").value;
  phone = document.getElementById("phone").value;
  creditCardNum = document.getElementById("creditCard").value;
  
  registerUser = {

	"fname" : firstname,
	"lname" : lastname,
	"email" : email,
	"pass" : password,
	"passStrength" : passwordStrength,
	"dob" : dob,
	"ldob" : dobLocal,
	"ssn" : ssn,
	"phone" : phone,
	"credit" : creditCardNum	
  };
  
//Call function to convert to a Json String
convertToJsonString();

//Call function to read from Json String
readFromJsonString();

//save Json object to Local and Session storage.
	if(typeof(Storage) !== "undefined"){
	alert("Saving to local and session Storage");
	localStore = localStorage.setItem('myJSONobject',jsonObj);		
	sessionStrore = sessionStorage.setItem('myJSONobject',jsonObj);
	}else{
		alert("your browser doesn't support storage");	
	}
}

//Converts javascript object registerUser to Json String
function convertToJsonString(){
	jsonObj = JSON.stringify(registerUser); 
}

//Read from Json String
function readFromJsonString(){
	alert("Reading From JsonString:" + jsonObj);
}

//Reads the data which is Locally stored
function readFromLocalStorage(){
	if(typeof(Storage) !== "undefined"){
		readStore = localStorage.getItem("myJSONobject");
		alert("Reading from Local Storage:" + readStore);
	}else{
		alert("your browser doesn't support storage");
	}

}

//Reads the data which is stored in a session. When browser is closed,the session data is cleared.
function readFromSessionStorage(){
	if(typeof(Storage) !== "undefined"){
		readStore = sessionStorage.getItem("myJSONobject");
		alert("Reading from Session Storage:" + readStore);
	}else{
		alert("your browser doesn't support storage");
	}

}

// Validate user Phone number
function isValidPhoneNum(){
	var regex = /^(\([1-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}/;
	var phone = document.getElementById('phone').value;
	if(!regex.test(phone)){
		alert("Please enter a valid phone number i.e: ###-###-####");
	}
}

// Validate user Email ID
function isValidEmail(){   
    var regex = /^(([^<>()[\]\\:.,;\s@\"]+(\.[^<>()[\]\\,;:.\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var email = document.getElementById('emailId').value;
   if (!regex.test(email)) {
    	alert("Please enter a valid email id e.g xxx.xx@xxx.xx");
   }
} 

// Validate the password and give out the password strength
function validatePassword(){

  var pass = document.getElementById("pwd").value; 
  var lowRegex= new RegExp("^(?=.*[a-z]{2})(?=.*[A-Z]{3})(?=.*[-+_!@#$%^&*.,?]{2}).+$"); 
  var mediumRegex= new RegExp("^(?=.*[a-z]{2})(?=.*[A-Z]{3})(?=.*[-+_!@#$%^&*.,?]{3}).+$");
  var goodRegex = new RegExp("^(?=.*[a-z]{2})(?=.*[A-Z]{3})(?=.*[-+_!@#$%^&*.,?]{6}).+$"); 
  
  if (!lowRegex.test(pass)) {
  	   document.getElementById("passwordStrength").innerHTML="not valid until you meet the password requirements";
        }else{
  	   document.getElementsByTagName("progress")[0].value="25";
           strength = "normal";
	   document.getElementById("passwordStrength").innerHTML=strength;
        }
 if (mediumRegex.test(pass)) {
            document.getElementsByTagName("progress")[0].value="50";
            strength = "medium";
	   document.getElementById("passwordStrength").innerHTML=strength;
        }
 if (goodRegex.test(pass)) {
           document.getElementsByTagName("progress")[0].value="100";
            strength = "strong";
	   document.getElementById("passwordStrength").innerHTML=strength;
        }
  //The password is invalid
  if(pass.length > 24){
		alert("Not a valid password.Length must be less than 24");
				
	}
  }
  
// Check if password and confirm password fields match
function checkPasswords(){

var pass = document.getElementById("pwd"); 
var confirmPass = document.getElementById("Cpwd"); 
var message = document.getElementById('confirmMessage');
var goodColor = "#66cc66";
var badColor = "#ff6666";

if(pass.value == confirmPass.value){
	confirmPass.style.backgroundColor = goodColor;
	message.style.color = goodColor;
	message.innerHTML = "Passwords Match!"
}else{
	confirmPass.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = "Passwords Do Not Match!"
}
}

//online and offline Events

window.addEventListener('load', function() {
  var status = document.getElementById("status");

  function updateOnlineStatus(event) {
    var condition = navigator.onLine ? "online" : "offline";

    status.className = condition;
    status.innerHTML = condition.toUpperCase();

    log.insertAdjacentHTML("beforeend", "Event: " + event.type + "; Status: " + condition);
  }

  window.addEventListener('online',  updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
});



